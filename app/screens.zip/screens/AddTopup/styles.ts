import { StyleSheet } from 'react-native';


const styles = StyleSheet.create({
  badge:{
marginRight:30
  },
  btnfinish:{
    marginTop:30,
    marginLeft:30,
    marginRight:30

  }
});

export default styles;
