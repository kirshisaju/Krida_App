import { StyleSheet } from 'react-native';


const styles = StyleSheet.create({
  container: {
 marginTop:180,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
   
  },
  createform:{
    marginLeft:20,
    marginRight:20
  
  },
  inputtext:{
    marginTop:10
  }
});

export default styles;
