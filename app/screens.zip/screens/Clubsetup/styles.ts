import { StyleSheet } from 'react-native';


const styles = StyleSheet.create({

  pagination_x: {
    position: 'absolute',
    bottom: 10,
    left: 0,
    right: 0,
    flexDirection: 'row',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent'
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  imghig:{
    height:150,
    width:150
  },
  mttext:{
    marginTop:20,
    fontSize:15
  },
  cardtitlepad:{
    paddingRight:30,
    
  },
  bgclr:{
    backgroundColor:'red',
    color:'white'

  },
  borderClubs:{
    borderColor: "#ddd",
    borderWidth: 1,
    marginTop:20,
    borderRadius: 1,
    padding:10,
  },
  clubsShield:{marginTop:13,
    backgroundColor:'grey',
  },
  padbg:{
   marginLeft:20,
   marginRight:20,
   marginTop:60
  },
  clubsShields:{marginTop:13,
    backgroundColor:'orange',
height:40,
width:40,
borderRadius: 20,

  },
  bgcont:{
    marginTop:200,
    backgroundColor:'red',
    color:'white'
  },
  ir:{
    marginTop: 25,
    height:40,
    marginLeft:20,
    backgroundColor: "#ffffff",
    textAlign: 'center',color: "#61dafb",
  },
  navBarLeftButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    width: 100,
    paddingLeft: 8
  },

  buttonText: {
  color:'black',
    fontSize: 14,
    position:'absolute',
    paddingTop:70,
   paddingLeft:12

  },
  buttonText2: {
    color:'black',
      fontSize: 14,
      position:'absolute',
      paddingTop: 100,
      paddingLeft:10
    }
 
});

export default styles;
