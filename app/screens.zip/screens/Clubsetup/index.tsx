import React from 'react';
import { Image, ScrollView, Switch, TouchableOpacity, View } from 'react-native';
import { Text, Button, List, Avatar, Title, Dialog, TextInput, Chip, Card, Badge, Paragraph } from 'react-native-paper';
import { useDispatch, useSelector } from 'react-redux';

import * as loginActions from 'app/store/actions/loginActions';
import styles from './styles';
import { ILoginState } from 'app/models/reducers/login';
import NavigationService from 'app/navigation/NavigationService';
import { Col, Grid, Row } from 'react-native-easy-grid';
import DropDown from 'react-native-paper-dropdown';
//import SelectDropdown from 'react-native-select-dropdown'
import Swiper from 'react-native-swiper';
import Colorsetup from '../Colorsetup';
import Logosetup from '../Logosetup';
import Icon from 'react-native-paper/lib/typescript/components/Icon';
import BottomSheet from 'reanimated-bottom-sheet';
import MemberShipDrawer from 'app/screens/membershipdrawer';
import AddMemberDrawer from 'app/screens/Addmemberdrawer';




interface IState {
  loginReducer: ILoginState;
}

const Clubsetup: React.FC = () => {
  const id = useSelector((state: IState) => state.loginReducer.id);
  
  const dispatch = useDispatch();
  const [visible1, setVisible1] = React.useState(false);
  const showDialog1 = () => setVisible1(true);
  const hideDialog1= () => setVisible1(false);
  const [text, setText] = React.useState('');
  const [showDropDown, setShowDropDown] = React.useState(false);
  const [visible2, setVisible2] = React.useState(false);
  const showDialog2 = () => setVisible2(true);
  const hideDialog2= () => setVisible2(false);
  const [isEnabled, setIsEnabled] = React.useState(false);
  const [isEnabled1, setIsEnabled1] = React.useState(false);
 

  const [gender, setGender] = React.useState();

  const genderList = [
    { label: "Male", value: "male" },

    { label: "Female", value: "female" },

    { label: "Others", value: "others" },
  ];
  const renderContent = () => ( 
    <View
    style={{
      backgroundColor: 'white',
      padding: 16,
      height: 1000,
      width:"100%",
      
    }}
  >
<MemberShipDrawer/>
  </View>
  );
  const sheetRef1 = React.useRef(null);
  const renderContent1 = () => ( 
    <View
    style={{
      backgroundColor: 'white',
      padding: 16,
      height: 1000,
      width:"100%",
      
    }}
  >
<AddMemberDrawer/>
  </View>
  );
  const sheetRef = React.useRef(null);
  return (
    <ScrollView>

<Swiper style={{height:750}} showsHorizontalScrollIndicator={true}  showsButtons={false} 
activeDotStyle={{backgroundColor:'red',width:50,height:5}}  
dotStyle={{width:50,height:5}}
paginationStyle={{bottom: undefined, left: undefined, top:10,paddingRight:70,marginTop:30 }} >
      <View style={styles.container} >

{/*<Image style={styles.imghig} source={require('../../assets/shi.png')}></Image > */}
<Text  style={styles.mttext}>Now lets Finish Setup Your Clubs</Text>

<Card.Title style={styles.cardtitlepad}
      titleStyle={{color: "rgba(0,0,0,0.7)", fontSize:18, fontWeight:'bold',paddingLeft:20,}}
      title="General Information"
      left={(props) =>   <Badge
        style={{ position: 'absolute',backgroundColor:'grey',height:20,width:20 }}
      > 1</Badge>} 
      right={(props) => <Text>Completed</Text>} 
      />
<Card.Title style={styles.cardtitlepad}
      titleStyle={{color: "rgba(0,0,0,0.7)", fontSize:18, fontWeight:'bold',paddingLeft:20,}}
      title="Logo & Design"
      left={(props) =>   <Badge
        style={{ position: 'absolute',backgroundColor:'grey',height:20,width:20 }}
      > 2</Badge>} 
      right={(props) => <Text>1 Min</Text>} 
      />
<Card.Title style={styles.cardtitlepad}
      titleStyle={{color: "rgba(0,0,0,0.7)", fontSize:18, fontWeight:'bold',paddingLeft:20,}}
      title="Membership"
      left={(props) =>   <Badge
        style={{ position: 'absolute',backgroundColor:'grey',height:20,width:20 }}
      > 3</Badge>} 
      right={(props) => <Text>2 Min</Text>} 
      />
<Card.Title style={styles.cardtitlepad}
      titleStyle={{color: "rgba(0,0,0,0.7)", fontSize:18, fontWeight:'bold',paddingLeft:20,}}
      title="Settings"
      left={(props) =>   <Badge
        style={{ position: 'absolute',backgroundColor:'grey',height:20,width:20 }}
      > 4</Badge>} 
      right={(props) => <Text>3 Min</Text>} 
      />
      <>
      <Button style={styles.bgclr}>Continue</Button>
      </>
      </View>
      
      <View style={styles.padbg}>
      <Text  style={styles.mttext}>Club Logo Design</Text>
        <List.Item style={styles.borderClubs}    onPress={showDialog1}
            titleStyle={{fontSize:15, fontWeight:'bold'}}
            title="Pick a logo"
            left={props =>  <Avatar.Icon size={24} icon="plus" style={styles.clubsShield}/>}
            right={props => <List.Icon {...props} icon="chevron-right"  />}
        />
        <List.Item style={styles.borderClubs} onPress={showDialog2}
            titleStyle={{fontSize:15, fontWeight:'bold'}}
            title="Pick a Color"
            left={props =>  <Avatar.Icon size={24} icon="plus" style={styles.clubsShield}/>}
            right={props => <List.Icon {...props} icon="chevron-right"    />}
        />
        <Text  style={styles.mttext}>Club Logo Preview</Text>
        <List.Item style={styles.borderClubs}
            titleStyle={{fontSize:15, fontWeight:'bold'}}
            title="Premier Club"  
            description="Batminton - social Club"
            left={props =>  <Avatar.Icon size={24} icon="shield" style={styles.clubsShields}/>}
        />

        <Button style={styles.bgcont}>Continue</Button>
      </View>
        <View style={styles.padbg}>
        <Text  style={styles.mttext}>Add Members</Text>
        <View style={{ flexDirection:'row' ,alignItems: 'flex-start',flexWrap: 'wrap',}}> 

        <TouchableOpacity style={styles.navBarLeftButton} >
        <Avatar.Icon size={24} icon="shield" style={styles.clubsShields}></Avatar.Icon> 
        <Text style={styles.buttonText}>From</Text>
        <Text style={styles.buttonText2}>Phone</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.navBarLeftButton}>
            <Avatar.Icon size={24} icon="shield" style={styles.clubsShields}></Avatar.Icon> 
          <Text style={styles.buttonText}>From</Text>
          <Text style={styles.buttonText2}>Facebook</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.navBarLeftButton}>
            <Avatar.Icon size={24} icon="shield" style={styles.clubsShields}></Avatar.Icon> 
          <Text style={styles.buttonText}>From</Text>
          <Text style={styles.buttonText2}>Google</Text>
        </TouchableOpacity>
    
        <TouchableOpacity style={styles.navBarLeftButton}>
            <Avatar.Icon size={24} icon="shield" style={styles.clubsShields}></Avatar.Icon> 
          <Text style={styles.buttonText}>From</Text>
          <Text style={styles.buttonText2}>krida</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.navBarLeftButton}  >
            <Avatar.Icon size={24} icon="shield" style={styles.clubsShields}></Avatar.Icon> 
          <Text style={styles.buttonText}>From</Text>
          <Text style={styles.buttonText2}  onPress={() => sheetRef1.current.snapTo(0)} >One-by-one</Text>
        </TouchableOpacity>
      </View> 

    <View style={{marginTop:50}}>
        <Title>Membership</Title>
        <Paragraph onPress={() => sheetRef.current.snapTo(0)} >Please Add Member First</Paragraph>
    </View>
    </View>

    <View style={styles.padbg}>
    <Text style={{marginTop:30,fontSize:20}}>Club Settings</Text>
          <List.Item style={{marginTop:30}}
              titleStyle={{fontSize:15, fontWeight:'bold' }}
              title="Searchable ,Visible is Public"
              description="Anyone Can Search The Club And Request To Join"
              right={props =>      <Switch
              trackColor={{ false: "#red", true: "green" }}
              thumbColor={isEnabled ? "#f5dd4b" : "#f4f3f4"}
              ios_backgroundColor="red"
              value={isEnabled}
              />}
          />
          <List.Item style={{marginTop:30}}
              titleStyle={{fontSize:15, fontWeight:'bold' }}
              title="Searchable ,Visible is Public"

              description="Anyone Can Search The Club And Request To Join"
              right={props =>      <Switch
              trackColor={{ false: "#767577", true: "#81b0ff" }}
              thumbColor={isEnabled1 ? "#f5dd4b" : "#f4f3f4"}
              ios_backgroundColor="red"
              value={isEnabled1}
              />}
          />
    </View>
    </Swiper>
    <BottomSheet
              ref={sheetRef}
              snapPoints={[450, 300, 0]}
              borderRadius={10}
              initialSnap={2}
              renderContent={renderContent}
      />
    <BottomSheet
              ref={sheetRef1}
              snapPoints={[450, 300, 0]}
              borderRadius={10}
              initialSnap={2}
              renderContent={renderContent1} 
      />
        <Dialog visible={visible1} onDismiss={hideDialog1}>
            <Logosetup/> 
        </Dialog>

        <Dialog visible={visible2} onDismiss={hideDialog2}>
            <Colorsetup/>
        </Dialog>
       
   </ScrollView>   
   
  );
};

export default Clubsetup;
