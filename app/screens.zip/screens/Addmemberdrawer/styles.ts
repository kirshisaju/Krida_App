import { StyleSheet } from 'react-native';
import { color } from 'react-native-reanimated';


const styles = StyleSheet.create({
  input: {
    margin: 3,
    height: 60,
    borderColor: 'black',
    borderWidth: 1
 },

 inputs: {
  margin: 3,
  height: 60,
  borderColor: 'black',
  borderWidth: 1,
  width:195
  
},
 inputWrap: {
  borderColor: '#cccccc',
  borderBottomWidth: 1,
  marginBottom: 10,
},
inputdate: {
fontSize: 14,
marginBottom : -12,
color: '#6a4595',
},
inputcvv: {
fontSize: 14,
marginBottom : -12,
color: '#6a4595',
},
 flex2:{
   flex:1
 },
 mb:{
   marginBottom:20
 },
 btn:{
   height:60,
   marginTop:4
 },
 backicon:{
   position:'absolute',
   marginLeft:300,
   marginTop:15

 },
 inputcou: {
  margin: 3,
  height: 60,
  borderColor: 'black',
  borderWidth: 1,
  width:110
  
},
inputaddnew:{
  margin: 3,
  height: 50,
  borderColor: 'black',
  borderWidth: 1,
  width:171,
  backgroundColor:'red',
  color:'white'
},

inputdone:{
  margin: 3,
  height: 50,
  borderColor: 'black',
  borderWidth: 1,
  width:171,
  backgroundColor:'red',
  color:'white'
},

inputpho: {
  margin: 3,
  height: 60,
  borderColor: 'black',
  borderWidth: 1,
  width:235
  
},
heightselect:{
  paddingTop:7
}

});

export default styles;
